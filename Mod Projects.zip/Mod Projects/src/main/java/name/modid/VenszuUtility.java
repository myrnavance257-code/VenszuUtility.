package name.modid;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class VenszuUtility implements ModInitializer {
    // 1. Register the '0' key
    public static KeyBinding menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
        "key.venszuutility.menu", 
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_0, 
        "category.venszuutility"
    ));

    @Override
    public void onInitialize() {
        // 2. This code runs 20 times a second to check if you pressed '0'
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                // For now, this just sends a message so you know it works!
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§b[Venszu] §fOpening Menu..."), false);
                }
            }
        });
    }
}
