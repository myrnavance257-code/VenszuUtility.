package name.modid;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class VenszuUtility implements ClientModInitializer {

    // 1. Create the Keybinding for the '0' key
    public static KeyBinding menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
        "key.venszuutility.menu", // Name in controls menu
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_0,          // The '0' key
        "category.venszuutility"  // Category in controls menu
    ));

    @Override
    public void onInitializeClient() {
        // This runs when the mod starts up
        System.out.println("Venszu Utility Initialized!");
    }
}
