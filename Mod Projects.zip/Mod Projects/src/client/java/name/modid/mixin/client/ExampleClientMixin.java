package name.modid.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Random;

@Mixin(ClientPlayerEntity.class)
public class ExampleMixin {
    private final Random random = new Random();

    @Inject(at = @At("HEAD"), method = "tick")
    private void onTick(CallbackInfo info) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.targetedEntity == null) return;

        // The "Fall-to-Crit" Logic
        if (!client.player.isOnGround() && client.player.getVelocity().y < 0) {
            
            // Anti-Cheat: Randomize cooldown between 90-100%
            float randomThreshold = 0.9f + (random.nextFloat() * 0.1f);
            
            if (client.player.getAttackCooldownProgress(0.5f) >= randomThreshold) {
                client.interactionManager.attackEntity(client.player, client.targetedEntity);
                client.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
